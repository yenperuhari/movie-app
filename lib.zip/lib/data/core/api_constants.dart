import 'package:flutter/material.dart';

class ApiConstants {
  ApiConstants._();

  static const String BASE_URL = "https://api.themoviedb.org/3/";
  static const String API_KEY = "5f892433629961ae4c226db453eb3649";
  static const String BASE_IMAGE_URL = "https://image.tmdb.org/t/p/w500";
}
