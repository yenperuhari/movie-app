import 'dart:convert';

import 'package:http/http.dart';
import 'package:jokermovies/data/core/api_constants.dart';
import 'package:jokermovies/data/models/movie_model.dart';
import 'package:jokermovies/data/models/movie_result_model.dart';

abstract class MovieRemoteDataSource {
  Future<List<MovieModel>> getTrending();
  Future<List<MovieModel>> getPopular();
}

class MovieRemoteDataSourceImpl extends MovieRemoteDataSource {
  final Client _client;

  MovieRemoteDataSourceImpl(this._client);

  @override
  Future<List<MovieModel>> getTrending() async {
    var trenuri = Uri.parse('trending/movie/day');
    var url = Uri.parse(
        '${ApiConstants.BASE_URL}trending/movie/day?api_key=${ApiConstants.API_KEY}');
    final response = await _client.get(trenuri);
    final movies =
        MovieResultModel.fromJson(response as Map<String, dynamic>).movies;
    print(movies);
    return movies!;
  }

  @override
  Future<List<MovieModel>> getPopular() async {
    var popuri = Uri.parse('movie/popular');
    var url = Uri.parse('${ApiConstants.BASE_URL}movie/popular?api_key=${ApiConstants.API_KEY}');
    final response = await _client.get(popuri);
    final movies =  MovieResultModel.fromJson(response as Map<String, dynamic>).movies;
    print(movies);
      return movies!;
   
  }
}
